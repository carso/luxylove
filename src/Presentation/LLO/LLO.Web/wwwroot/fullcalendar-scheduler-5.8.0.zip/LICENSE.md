
For complete licensing information, visit:
http://fullcalendar.io/scheduler/license

FullCalendar Scheduler is tri-licensed, meaning you must choose
one of three licenses to use. Here is a summary of those licenses:

- Commercial License
  (a paid license, meant for commercial use)
  http://fullcalendar.io/scheduler/license-details

- Creative Commons Non-Commercial No-Derivatives
  (meant for trial and non-commercial use)
  https://creativecommons.org/licenses/by-nc-nd/4.0/

- GPLv3 License
  (meant for open-source projects)
  http://www.gnu.org/licenses/gpl-3.0.en.html
